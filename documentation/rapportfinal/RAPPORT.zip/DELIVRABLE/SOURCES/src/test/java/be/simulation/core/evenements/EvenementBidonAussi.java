package be.simulation.core.evenements;

/**
 * Classe utilisée pour les tests
 * 
 * @author Dubois Sebastien
 */
public class EvenementBidonAussi extends EvenementBidon {
	public EvenementBidonAussi(long tempsPrevu) {
		super(tempsPrevu);
	}
}
